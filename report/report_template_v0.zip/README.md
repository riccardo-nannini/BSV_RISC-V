# Report template

Based on the ``article`` class, this is an example of simple report for projects, meant for users who approach Latex for the first time.

Requirements:

* pdflatex
* biber

To compile run ``make``, to clean intermediate files run ``make clean``and to clean everything ``make distclean``.
